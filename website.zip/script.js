const ideas = [
  { id: 'study-partner', icon: '🤖', category: 'AI', title: 'AI Study Partner', description: 'An AI-powered platform that creates personalized study plans for students.', problem: 'Students struggle to create personalized study schedules and stay consistent across multiple subjects.', solution: 'An intelligent learning companion that turns subjects, available time and learning goals into a flexible plan.', users: 'Students, parents, tutors and education teams.', features: ['AI study planning', 'Progress tracking', 'Smart reminders', 'Personalized recommendations'], opportunity: 'The global edtech market continues to move toward adaptive, outcomes-focused learning products.', technology: 'LLM APIs, a responsive web app, calendar integrations and a lightweight analytics layer.', difficulty: 'Beginner', popularity: 98, date: '2026-08-14' },
  { id: 'cybershield', icon: '🛡️', category: 'Cybersecurity', title: 'CyberShield', description: 'A platform that helps students learn cybersecurity through interactive challenges.', problem: 'Students need practical security skills but lack safe, engaging ways to practice them.', solution: 'A guided challenge platform that turns cybersecurity concepts into hands-on missions.', users: 'Students, educators, bootcamps and early-career security teams.', features: ['Interactive labs', 'Progress paths', 'Skill badges', 'Mentor feedback'], opportunity: 'The security skills gap creates demand for accessible, practice-based learning.', technology: 'Sandboxed challenges, progress analytics, role-based access and secure cloud infrastructure.', difficulty: 'Intermediate', popularity: 92, date: '2026-07-26' },
  { id: 'ecotrack', icon: '🌱', category: 'Sustainability', title: 'EcoTrack', description: 'An intelligent platform that helps users track and reduce their environmental impact.', problem: 'Sustainability goals feel abstract when people cannot see the impact of daily choices.', solution: 'A friendly impact dashboard that turns purchases, travel and energy habits into actionable steps.', users: 'Households, teams and sustainability-minded brands.', features: ['Impact dashboard', 'Goal setting', 'Verified tips', 'Community challenges'], opportunity: 'Consumers and organizations need simple ways to turn climate intent into measurable action.', technology: 'Data visualization, partner APIs, recommendation models and carbon factor datasets.', difficulty: 'Medium', popularity: 87, date: '2026-08-30' },
  { id: 'finlit', icon: '◈', category: 'FinTech', title: 'PocketPilot', description: 'A visual money coach that makes personal finance feel clear, contextual and achievable.', problem: 'Traditional finance tools expose numbers without helping people decide what to do next.', solution: 'A goal-based coach that explains spending patterns and gives users one useful next step at a time.', users: 'Young professionals, students and first-time investors.', features: ['Goal plans', 'Smart categorization', 'Cash-flow forecasts', 'Plain-language insights'], opportunity: 'A new generation of customers expects financial guidance to be transparent and human.', technology: 'Open banking APIs, rules engines, data visualization and optional AI explanations.', difficulty: 'Hard', popularity: 84, date: '2026-08-02' },
  { id: 'cyberbrief', icon: '◉', category: 'Cybersecurity', title: 'CyberBrief', description: 'A security briefing workspace that helps small teams understand and act on their risk.', problem: 'Small businesses receive security alerts without the time or expertise to interpret them.', solution: 'A focused workspace that translates signals into prioritized, plain-language actions.', users: 'Small businesses, agencies and startup operations teams.', features: ['Risk snapshots', 'Action checklists', 'Team assignments', 'Weekly briefings'], opportunity: 'Security is shifting from specialist-only tooling toward accessible operations software.', technology: 'Threat intelligence feeds, role-based access, browser extensions and audit logs.', difficulty: 'Hard', popularity: 79, date: '2026-07-11' },
  { id: 'mentorloop', icon: '✦', category: 'Education', title: 'MentorLoop', description: 'A structured mentorship network that turns one-off advice into lasting progress.', problem: 'Mentorship is valuable but conversations often lack context, goals and follow-through.', solution: 'A guided matching and check-in platform built around practical milestones.', users: 'Career changers, universities, communities and growing teams.', features: ['Goal matching', 'Session prompts', 'Progress milestones', 'Resource trails'], opportunity: 'People want trusted, structured support as careers become less linear.', technology: 'Matching logic, video integrations, calendar sync and collaborative notes.', difficulty: 'Easy', popularity: 74, date: '2026-08-21' }
];

const getSaved = () => JSON.parse(localStorage.getItem('idealaunch-saved') || '[]');
const setSaved = (ids) => localStorage.setItem('idealaunch-saved', JSON.stringify(ids));
const currentUser = () => JSON.parse(localStorage.getItem('idealaunch-user') || 'null');
const initials = (name) => (name || 'Guest').split(' ').map(word => word[0]).slice(0, 2).join('').toUpperCase();
const protectedPages = ['index.html', 'explore.html', 'saved.html', 'profile.html', 'details.html'];

function requireSession() {
  const page = location.pathname.split('/').pop() || 'index.html';
  if (protectedPages.includes(page) && sessionStorage.getItem('isLoggedIn') !== 'true') {
    location.href = 'login.html';
    return false;
  }
  return true;
}

function showToast(message) {
  let toast = document.querySelector('.toast');
  if (!toast) { toast = document.createElement('div'); toast.className = 'toast'; document.body.appendChild(toast); }
  toast.textContent = message;
  toast.classList.add('show');
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove('show'), 2600);
}

function ideaCard(idea) {
  const saved = getSaved().includes(idea.id);
  return `<article class="idea-card glass fade-in" data-idea-id="${idea.id}">
    <div class="idea-top"><div class="idea-icon">${idea.icon}</div><span class="tag">${idea.category}</span></div>
    <h3>${idea.title}</h3><p>${idea.description}</p>
    <div class="idea-footer"><a class="btn btn-secondary btn-small" href="details.html?id=${idea.id}">View Idea <span>↗</span></a>
      <button class="btn btn-ghost btn-small save-btn ${saved ? 'saved' : ''}" data-save-id="${idea.id}" aria-label="${saved ? 'Remove saved idea' : 'Save idea'}">${saved ? '♥' : '♡'}</button>
    </div>
  </article>`;
}

function renderCards(list, target) {
  if (!target) return;
  target.innerHTML = list.length ? list.map(ideaCard).join('') : `<div class="empty-state glass"><div class="stat-icon">💡</div><h2>No saved ideas yet.</h2><p>Explore startup ideas and save the ones that inspire you.</p><a class="btn btn-primary" href="explore.html">Explore Ideas →</a></div>`;
  target.querySelectorAll('[data-save-id]').forEach(button => button.addEventListener('click', () => toggleSave(button.dataset.saveId)));
}

function toggleSave(id) {
  const saved = getSaved();
  const exists = saved.includes(id);
  setSaved(exists ? saved.filter(item => item !== id) : [...saved, id]);
  document.querySelectorAll(`[data-save-id="${id}"]`).forEach(button => { button.classList.toggle('saved', !exists); button.textContent = exists ? '♡ Save' : '♥ Saved'; });
  showToast(exists ? 'Idea removed from your collection.' : 'Idea saved to your collection.');
  const savedGrid = document.querySelector('#saved-grid');
  if (savedGrid) renderCards(ideas.filter(idea => getSaved().includes(idea.id)), savedGrid);
  updateStats();
}

function updateStats() {
  const savedCount = getSaved().length;
  document.querySelectorAll('[data-saved-count]').forEach(node => node.textContent = savedCount);
}

function setupNav() {
  const toggle = document.querySelector('.menu-toggle');
  const links = document.querySelector('.nav-links');
  toggle?.addEventListener('click', () => links?.classList.toggle('open'));
  const page = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-link').forEach(link => { if (link.getAttribute('href') === page) link.classList.add('active'); });
  document.querySelectorAll('[data-logout]').forEach(button => button.addEventListener('click', () => { sessionStorage.removeItem('isLoggedIn'); localStorage.removeItem('idealaunch-user'); location.href = 'login.html'; }));
}

function setupExplore() {
  const grid = document.querySelector('#explore-grid'); if (!grid) return;
  const search = document.querySelector('#idea-search'); const sort = document.querySelector('#idea-sort'); let category = 'All';
  const draw = () => { const query = search.value.toLowerCase().trim(); let list = ideas.filter(idea => (category === 'All' || idea.category === category) && `${idea.title} ${idea.description} ${idea.category}`.toLowerCase().includes(query)); if (sort.value === 'popular') list.sort((a, b) => b.popularity - a.popularity); if (sort.value === 'newest') list.sort((a, b) => new Date(b.date) - new Date(a.date)); if (sort.value === 'trending') list.sort((a, b) => b.popularity % 7 - a.popularity % 7); renderCards(list, grid); };
  search.addEventListener('input', draw); sort.addEventListener('change', draw);
  document.querySelectorAll('[data-category]').forEach(button => button.addEventListener('click', () => { category = button.dataset.category; document.querySelectorAll('[data-category]').forEach(item => item.classList.toggle('active', item === button)); draw(); }));
  draw();
}

function setupDetails() {
  const target = document.querySelector('#detail-content'); if (!target) return;
  const idea = ideas.find(item => item.id === new URLSearchParams(location.search).get('id')) || ideas[0]; const saved = getSaved().includes(idea.id);
  target.innerHTML = `<div class="detail-header"><div><span class="tag">${idea.category}</span><h1 class="detail-title">${idea.title}</h1><p class="detail-lead">${idea.description}</p></div><div class="idea-icon">${idea.icon}</div></div>
    <div class="hero-actions"><button class="btn btn-primary save-btn ${saved ? 'saved' : ''}" data-save-id="${idea.id}">${saved ? '♥ Saved Idea' : '♡ Save Idea'}</button><a class="btn btn-ghost" href="explore.html">← Back to Explore</a></div>
    <div class="detail-section"><h2>Problem</h2><p>${idea.problem}</p></div><div class="detail-section"><h2>Solution</h2><p>${idea.solution}</p></div>
    <div class="detail-section"><h2>Target Users</h2><p>${idea.users}</p></div><div class="detail-section"><h2>Key Features</h2><ul>${idea.features.map(feature => `<li>${feature}</li>`).join('')}</ul></div>
    <div class="detail-section"><h2>Business Opportunity</h2><p>${idea.opportunity}</p></div><div class="detail-section"><h2>Technology Suggestions</h2><p>${idea.technology}</p></div><div class="detail-section"><h2>Difficulty Level</h2><p><span class="tag">${idea.difficulty}</span></p></div>`;
  target.querySelector('[data-save-id]').addEventListener('click', () => { toggleSave(idea.id); target.querySelector('[data-save-id]').classList.toggle('saved', getSaved().includes(idea.id)); target.querySelector('[data-save-id]').textContent = getSaved().includes(idea.id) ? '♥ Saved Idea' : '♡ Save Idea'; });
}

function setupAuth() {
  const form = document.querySelector('[data-auth-form]'); if (!form) return;
  form.addEventListener('submit', event => { event.preventDefault(); const fields = Object.fromEntries(new FormData(form).entries()); const message = form.querySelector('.form-message');
    if (!fields.email || !fields.email.includes('@')) { message.textContent = 'Please enter a valid email address.'; return; }
    if (!fields.password || fields.password.length < 6) { message.textContent = 'Password must be at least 6 characters.'; return; }
    if (form.dataset.authForm === 'signup' && fields.password !== fields.confirmPassword) { message.textContent = 'Passwords do not match yet.'; return; }
    localStorage.setItem('idealaunch-user', JSON.stringify({ name: fields.name || fields.email.split('@')[0], email: fields.email, joined: '2026' })); sessionStorage.setItem('isLoggedIn', 'true'); message.textContent = ''; showToast(form.dataset.authForm === 'signup' ? 'Account created. Welcome to IDEALAUNCH.' : 'Welcome back.'); setTimeout(() => { location.href = 'index.html'; }, 550);
  });
}

function setupPasswordVisibility() {
  document.querySelectorAll('[data-password-toggle]').forEach(button => button.addEventListener('click', () => {
    const input = document.getElementById(button.dataset.passwordToggle);
    input.type = input.type === 'password' ? 'text' : 'password';
    button.textContent = input.type === 'password' ? 'Show' : 'Hide';
  }));
}

function setupProfile() {
  const user = currentUser() || { name: 'Guest Explorer', email: 'guest@idealaunch.app', joined: '2026' }; document.querySelectorAll('[data-user-name]').forEach(node => node.textContent = user.name); document.querySelectorAll('[data-user-email]').forEach(node => node.textContent = user.email); document.querySelectorAll('[data-avatar]').forEach(node => node.textContent = initials(user.name)); document.querySelectorAll('[data-joined]').forEach(node => node.textContent = user.joined);
  document.querySelectorAll('[data-explored-count]').forEach(node => node.textContent = localStorage.getItem('idealaunch-explored') || '86'); document.querySelectorAll('[data-category-count]').forEach(node => node.textContent = '5'); updateStats();
}

document.addEventListener('DOMContentLoaded', () => { if (!requireSession()) return; setupNav(); setupExplore(); setupDetails(); setupAuth(); setupPasswordVisibility(); setupProfile(); updateStats(); document.querySelectorAll('[data-featured]').forEach(target => renderCards(ideas.slice(0, 3), target)); const savedGrid = document.querySelector('#saved-grid'); if (savedGrid) renderCards(ideas.filter(idea => getSaved().includes(idea.id)), savedGrid); });
